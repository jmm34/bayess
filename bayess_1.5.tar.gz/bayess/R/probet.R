probet=function(a,b,c,alpha)
{
coc=(1-c)/c
pbeta(b,alpha,alpha*coc)-pbeta(a,alpha,coc)
}